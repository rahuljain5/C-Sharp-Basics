﻿using AIRecommendationEngine.BusinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecommendationConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> baseArray = new List<int>();
            List<int> dataArray = new List<int>();
            baseArray.Add(1);
            baseArray.Add(7);
            baseArray.Add(0);
            baseArray.Add(3);
            baseArray.Add(4);
            baseArray.Add(1);
            baseArray.Add(6);
            baseArray.Add(4);
            baseArray.Add(8);
            baseArray.Add(7);
            baseArray.Add(2);
            baseArray.Add(1);
            baseArray.Add(0);
            baseArray.Add(4);
            dataArray.Add(1);
            dataArray.Add(7);
            dataArray.Add(0);
            dataArray.Add(3);
            dataArray.Add(4);
            dataArray.Add(1);
            dataArray.Add(6);
            dataArray.Add(4);
            dataArray.Add(8);
            dataArray.Add(7);
            dataArray.Add(2);
            dataArray.Add(1);
            dataArray.Add(0);
            dataArray.Add(4);
            Console.WriteLine(PearsonCorrelation.FindCoefficient(baseArray, dataArray));
        }
    }
}
