﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIRecommendationEngine.BusinessLayer
{
    public class PearsonCorrelation 
    {
        static public double FindCoefficient(List<int> baseArray, List<int> dataArray)
        {
            double correlationCoefficent;
            if(baseArray.Count < dataArray.Count)
            {
                dataArray.RemoveRange(baseArray.Count, (dataArray.Count - baseArray.Count));
            }
            else if(dataArray.Count < baseArray.Count)
            {
                for(int i = dataArray.Count; i< baseArray.Count; i++)
                {
                    baseArray[i]++;
                    dataArray.Add(1);
                }
            }
            if(baseArray.Contains(0) || dataArray.Contains(0))
            {
                for (int i = 0; i < baseArray.Count; i++)
                {
                    if((baseArray[i]==0) || (dataArray[i] == 0))
                    {
                        baseArray[i]++;
                        dataArray[i]++;
                    }
                }
            }
            int sumX = baseArray.Sum();
            int sumY = dataArray.Sum();
            int[] xy = new int[baseArray.Count];
            int[] x2 = new int[baseArray.Count];
            int[] y2 = new int[baseArray.Count];
            for(int i=0; i < baseArray.Count; i++)
            {
                x2[i] = (baseArray[i] * baseArray[i]);
                y2[i] = (dataArray[i] * dataArray[i]);
                xy[i] = baseArray[i] * dataArray[i];
                //Console.WriteLine(baseArray[i] + ", "+ dataArray[i]);
            }

            int sumXY = xy.Sum();
            int sumX2 = x2.Sum();
            int sumy2 = y2.Sum();
            int n = dataArray.Count;
            double r1 = ((n * sumXY) - (sumX * sumY));
            double r2 = (Math.Sqrt(((n * sumX2) - (sumX * sumX)) * ((n * sumy2) - (sumY * sumY))));
            //Console.WriteLine($"{n}, {sumX}, {sumY}, {sumXY}, {sumX2}, {sumy2}, {r1}, {r2}");
            correlationCoefficent = ( r1 / r2);
            return correlationCoefficent;
        } 
    }
}
